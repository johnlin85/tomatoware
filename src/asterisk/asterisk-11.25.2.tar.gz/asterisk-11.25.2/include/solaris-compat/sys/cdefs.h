#ifndef __SYS_CDEFS_H_
#define __SYS_CDEFS_H_

#define __BEGIN_DECLS
#define __END_DECLS

#define __P(p) p


#endif
