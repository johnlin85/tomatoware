Third Party Software

This directory contains third party software that is
used by PJ project.

= Building the third party libraries =

Go to build directory, rather than building the library
using the project files/Makefiles provided by the software.


= Versions =

speex:		SVN -r12832
portaudio:	SVN -r1186
gsm:		gsm-1.0.12
ilbc:		from RFC
resample:	lib-resample, I think version 1.7
srtp		libsrtp-1.4.4
