# SysV IPC is an optional Cygwin package
#
# Starting with cygwin 1.5.7, cygipc is deprecated in favor of
# cygserver (which requires no extra libs).
# Uncomment if for some reason you need to get this to work with cygipc.
#$self->{LIBS} = ['-lcygipc']
