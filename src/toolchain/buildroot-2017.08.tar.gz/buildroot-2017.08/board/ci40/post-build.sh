#!/bin/sh

# Copy to target
cp ${BINARIES_DIR}/vmlinux.gz.itb ${TARGET_DIR}/fitImage
